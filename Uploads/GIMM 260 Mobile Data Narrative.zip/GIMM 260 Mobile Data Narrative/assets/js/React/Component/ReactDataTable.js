//Anonymous Function
(() => {
    //This is the logic for a <Filters /> HTML element
    const Filters = (props) => {
        let updateSubCount = (clickEvent) => {
            props.updateFormState({
                subCount: clickEvent.target.value,
            });
        }

        let updateName = (inputEvent) => {
            props.updateFormState({
                name: inputEvent.target.value,
            });
        };

        let updateControversyCount = (inputEvent) => {
            props.updateFormState({
                controversyCount: inputEvent.target.value,
            });
        };

        let updateGenre = (clickEvent) => {
            props.updateFormState({
                genre: clickEvent.target.value,
            });
        }



        return (
            <React.Fragment>
                <div className='container'>
                    <div className='row'>
                        <div className='col-md-1'></div>
                        <div className='col-md-3'>
                            <b>Sub Count</b>
                            <br></br>
                            <b>Genre</b>
                        </div>
                        <div className='col-md-2'>
                            <select
                                onChange={updateSubCount}
                            >
                                <option value="">N/A</option>
                                <option value="high">Highest Sub Counts</option>
                                <option value="low">Lower Sub Counts</option>
                            </select>
                            <select
                                onChange={updateGenre}
                            >
                                <option value="">N/A</option>
                                <option>Entertainment</option>
                                <option>Entertainment (Company)</option>
                                <option>Music</option>
                                <option>Music (Company)</option>
                            </select>

                            <b>Name</b>
                            <input
                                type="text"
                                placeholder="Enter controversy count"
                                onChange={updateName}
                            />

                            <b>Controversy Count</b>
                            <input
                                type="text"
                                placeholder="Enter controversy count"
                                onChange={updateControversyCount}
                            />


                        </div>
                        <div className='col-md-3'></div>

                    <div className='col-md-2'></div>
                    <div className='col-md-1'></div>
                </div>
            </div>
            </React.Fragment >
        )
}

    //This is the logic for a <DataTable /> HTML element
    const DataTable = (props) => {
    return (
        <div className="container">
            <div className="row">
                <div className="col-md-12 text-center">
                    <h1>Youtuber Controversies</h1>
                </div>
            </div>


            <div className="row">
                <div className="col-md-2"></div>
                <div id="mobiledatatable" className="col-md-8 table-responsive">
                    <table className="table text-center table-striped">
                        <thead>
                            <tr>
                                <th>Youtuber's Name</th>
                                <th>Genre</th>
                                <th>Number of Subscribers (In millions)</th>
                                <th>Number of Controversies</th>
                            </tr>
                        </thead>
                        <tbody>
                            {props.dataToDisplay.map((row, i) => {
                                return (
                                    <tr key={i}>
                                        <td>{row.name}</td>
                                        <td>{row.genre}</td>
                                        <td>{row.subCount}</td>
                                        <td>{row.controversyCount}</td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>
                <div className="col-md-2"></div>
            </div>
        </div>
    )
}

class ReactDataTable extends React.Component {
    constructor(props) {
        super(props);

        this.originalData = props.originalData;
        this.state = {
            name: '',
            genre: '',
            subCount: '',
            controversyCount: '',
        };

        this.updateFormState = this.updateFormState.bind(this);
    }

    updateFormState(specification) {
        this.setState(specification);
    }

    render() {
        let filteredData = this.originalData;

        //used Chatgpt to give ideas for this
        if (this.state.subCount === 'high') {
            filteredData = filteredData.filter((row) => Number(row.subCount) > 100);
        } else if (this.state.subCount === 'low') {
            filteredData = filteredData.filter((row) => Number(row.subCount) <= 100);
        }

        if (this.state.genre !== '') {
            filteredData = filteredData.filter((row) => row.genre === this.state.genre
            );
        }
        if (this.state.controversyCount !== '') {
            filteredData = filteredData.filter((row) => row.controversyCount.toLowerCase().includes(this.state.controversyCount.toLowerCase())
            );
        }

        if (this.state.name !== '') {
            filteredData = filteredData.filter((row) => row.name.toLowerCase().includes(this.state.name.toLowerCase())
            );
        }

        return (
            <React.Fragment>
                <Filters
                    updateFormState={this.updateFormState}
                />

                <br></br>

                <DataTable
                    dataToDisplay={filteredData}
                />
            </React.Fragment>
        );
    }
}
const youtuberData = [
    {
    "name": "MrBeast",
    "genre": "Entertainment",
    "subCount": "320",
    "controversyCount": "Uncountable"
    },
    {
    "name": "T-Series",
    "genre": "Music",
    "subCount": "276",
    "controversyCount": "Uncountable"
    },
    {
    "name": "Cocomelon - Nursery Rhymes",
    "genre": "Education",
    "subCount": "184",
    "controversyCount": "Uncountable"
    },
    {
    "name": "YouTube Movies",
    "genre": "Entertainment (Company)",
    "subCount": "184",
    "controversyCount": "None"
    },
    {
    "name": "SET India",
    "genre": "Entertainment (Company)",
    "subCount": "178",
    "controversyCount": "None"
    },
    {
    "name": "Kids Diana Show",
    "genre": "Entertainment",
    "subCount": "126",
    "controversyCount": "Multiple"
    },
    {
    "name": "Vlad and Niki",
    "genre": "Entertainment",
    "subCount": "125",
    "controversyCount": "Multiple"
    },
    {
    "name": "Like Nastya",
    "genre": "Entertainment",
    "subCount": "121",
    "controversyCount": "None"
    },
    {
    "name": "PewDiePie",
    "genre": "Entertainment",
    "subCount": "111",
    "controversyCount": "Uncountable"
    },
    {
    "name": "Zee Music",
    "genre": "Music (Company)",
    "subCount": "111",
    "controversyCount": "Multiple"
    },
    {
    "name": "WWE",
    "genre": "Sports",
    "subCount": "104",
    "controversyCount": "Uncountable"
    },
    {
    "name": "Goldmines",
    "genre": "Film",
    "subCount": "100",
    "controversyCount": "???"
    },
    {
    "name": "Sony SAB",
    "genre": "Entertainment (Company)",
    "subCount": "96.2",
    "controversyCount": "None"
    },
    {
    "name": "Blackpink",
    "genre": "Music",
    "subCount": "94.9",
    "controversyCount": "Multiple"
    },
    {
    "name": "ChuChu TV Nursery Rhymes & Kids Songs",
    "genre": "Education",
    "subCount": "93.5",
    "controversyCount": "???"
    },
    {
    "name": "Stokes Twins",
    "genre": "Entertainment",
    "subCount": "91.9",
    "controversyCount": "Many"
    },
    {
    "name": "Zee TV",
    "genre": "Entertainment",
    "subCount": "84.6",
    "controversyCount": "Multiple"
    },
    {
    "name": "5-Minute Crafts",
    "genre": "How-to",
    "subCount": "80.9",
    "controversyCount": "Uncountable"
    },
    {
    "name": "BANGTANTV",
    "genre": "Music",
    "subCount": "79.1",
    "controversyCount": "Multiple"
    },
    {
    "name": "Pinkfong",
    "genre": "Education",
    "subCount": "78.1",
    "controversyCount": "Many"
    },
    {
    "name": "Colors TV",
    "genre": "Entertainment (Company)",
    "subCount": "76.5",
    "controversyCount": "Multiple"
    },
    {
    "name": "Hybe Labels",
    "genre": "Music (Company)",
    "subCount": "75.8",
    "controversyCount": "Multiple"
    },
    {
    "name": "Justin Bieber",
    "genre": "Music",
    "subCount": "73.9",
    "controversyCount": "Many"
    },
    {
    "name": "T-Series Bhakti Sagar",
    "genre": "Music",
    "subCount": "71",
    "controversyCount": "???"
    },
    {
    "name": "Shemaroo Filmi Gaane",
    "genre": "Music",
    "subCount": "69.7",
    "controversyCount": "???"
    },
    {
    "name": "Tips Official",
    "genre": "Entertainment",
    "subCount": "69.3",
    "controversyCount": "???"
    },
    {
    "name": "A4",
    "genre": "Entertainment",
    "subCount": "68.2",
    "controversyCount": "???"
    },
    {
    "name": "Aaj Tak",
    "genre": "News",
    "subCount": "67.8",
    "controversyCount": "???"
    },
    {
    "name": "Canal KondZilla",
    "genre": "Music",
    "subCount": "67.4",
    "controversyCount": "???"
    },
    {
    "name": "El Reino Infantil",
    "genre": "Music",
    "subCount": "66.3",
    "controversyCount": "???"
    },
    {
    "name": "ZAMZAM ELECTRONICS TRADING",
    "genre": "Entertainment",
    "subCount": "65.3",
    "controversyCount": "???"
    },
    {
    "name": "Infobells - Hindi",
    "genre": "Education",
    "subCount": "65",
    "controversyCount": "???"
    },
    {
    "name": "UR Cristiano",
    "genre": "Entertainment/Sports",
    "subCount": "64.7",
    "controversyCount": "Multiple"
    },
    {
    "name": "Toys and Colors",
    "genre": "Entertainment",
    "subCount": "64.1",
    "controversyCount": "???"
    },
    {
    "name": "Wave Music",
    "genre": "Music",
    "subCount": "63.1",
    "controversyCount": "???"
    },
    {
    "name": "김프로KIMPRO",
    "genre": "Entertainment",
    "subCount": "62.7",
    "controversyCount": "???"
    },
    {
    "name": "Eminem Music",
    "genre": "Music",
    "subCount": "62.4",
    "controversyCount": "Uncountable"
    },
    {
    "name": "Alan Chikin Chow",
    "genre": "Entertainment",
    "subCount": "62.4",
    "controversyCount": "???"
    },
    {
    "name": "Movieclips",
    "genre": "Film",
    "subCount": "62.3",
    "controversyCount": "???"
    },
    {
    "name": "Sony Music India",
    "genre": "Music",
    "subCount": "62.1",
    "controversyCount": "???"
    },
    {
    "name": "YRF",
    "genre": "Music",
    "subCount": "62",
    "controversyCount": "???"
    },
    {
    "name": "HAR PAL GEO",
    "genre": "Entertainment",
    "subCount": "60.7",
    "controversyCount": "Multiple"
    },
    {
    "name": "Dude Perfect",
    "genre": "Comedy",
    "subCount": "60.4",
    "controversyCount": "Minimal"
    },
    {
    "name": "Taylor Swift",
    "genre": "Music",
    "subCount": "60.1",
    "controversyCount": "Uncountable"
    },
    {
    "name": "LooLoo Kids",
    "genre": "Music",
    "subCount": "58.4",
    "controversyCount": "???"
    },
    {
    "name": "ARY Digital HD",
    "genre": "Entertainment",
    "subCount": "58",
    "controversyCount": "???"
    },
    {
    "name": "Mark Rober",
    "genre": "Edutainment",
    "subCount": "57.8",
    "controversyCount": "One"
    },
    {
    "name": "KL BRO Biju Rithvik",
    "genre": "Vlogging",
    "subCount": "57.5",
    "controversyCount": "None"
    },
    {
    "name": "Marshmello",
    "genre": "Music",
    "subCount": "57.4",
    "controversyCount": "None"
    },
    {
    "name": "BillionSurpriseToys",
    "genre": "Entertainment",
    "subCount": "57.4",
    "controversyCount": "???"
    },
    {
    "name": "Fede Vigevani",
    "genre": "Entertainment",
    "subCount": "57.1",
    "controversyCount": "None"
    },
    {
    "name": "PANDA BOI",
    "genre": "Entertainment",
    "subCount": "55.6",
    "controversyCount": "Minimal"
    },
    {
    "name": "Shemaroo",
    "genre": "Entertainment",
    "subCount": "55.5",
    "controversyCount": "Multiple"
    },
    {
    "name": "Ed Sheeran",
    "genre": "Music",
    "subCount": "55.2",
    "controversyCount": "Multiple"
    },
    {
    "name": "Ariana Grande",
    "genre": "Music",
    "subCount": "54.7",
    "controversyCount": "Many"
    },
    {
    "name": "YOLO AVENTURAS",
    "genre": "Sports",
    "subCount": "54.5",
    "controversyCount": "???"
    },
    {
    "name": "Billie Eilish",
    "genre": "Music",
    "subCount": "53.2",
    "controversyCount": "Uncountable"
    },
    {
    "name": "Get Movies",
    "genre": "Film",
    "subCount": "52.7",
    "controversyCount": "???"
    },
    {
    "name": "आचार्य प्रशा…",
    "genre": "Education",
    "subCount": "52.6",
    "controversyCount": "???"
    },
    {
    "name": "Mikecrack",
    "genre": "Games",
    "subCount": "52.6",
    "controversyCount": "???"
    },
    {
    "name": "SonyMusicIndiaVEVO",
    "genre": "Music",
    "subCount": "52.4",
    "controversyCount": "None (channel-wise)"
    },
    {
    "name": "Jess No Limit",
    "genre": "Entertainment",
    "subCount": "52.1",
    "controversyCount": "Multiple"
    },
    {
    "name": "JuegaGerman",
    "genre": "Games",
    "subCount": "51.3",
    "controversyCount": "???"
    },
    {
    "name": "Маша и Медведь",
    "genre": "Education",
    "subCount": "50.8",
    "controversyCount": "???"
    },
    {
    "name": "ABS-CBN Entertainment",
    "genre": "Entertainment",
    "subCount": "50",
    "controversyCount": "Multiple"
    },
    {
    "name": "Alejo Igoa",
    "genre": "Entertainment",
    "subCount": "49.9",
    "controversyCount": "None (channel-wise)"
    },
    {
    "name": "BETER BÖCÜK",
    "genre": "Entertainment",
    "subCount": "49.5",
    "controversyCount": "None"
    },
    {
    "name": "Masha and The Bear",
    "genre": "Film",
    "subCount": "49.5",
    "controversyCount": "Multiple"
    },
    {
    "name": "JioCinema Kids",
    "genre": "Entertainment",
    "subCount": "48.7",
    "controversyCount": "Multiple"
    },
    {
    "name": "StarPlus",
    "genre": "Entertainment",
    "subCount": "48.4",
    "controversyCount": "Minimal"
    },
    {
    "name": "Bad Bunny",
    "genre": "Music",
    "subCount": "48.3",
    "controversyCount": "Multiple"
    },
    {
    "name": "Fernanfloo",
    "genre": "Games",
    "subCount": "47.9",
    "controversyCount": "None"
    },
    {
    "name": "LUCCAS NETO - LUCCAS TOON",
    "genre": "Entertainment",
    "subCount": "47.9",
    "controversyCount": "None"
    },
    {
    "name": "Saregama Music",
    "genre": "Music",
    "subCount": "47.6",
    "controversyCount": "Minimal"
    },
    {
    "name": "Badabun",
    "genre": "Entertainment",
    "subCount": "47.6",
    "controversyCount": "Multiple"
    },
    {
    "name": "Ricis Official",
    "genre": "Entertainment",
    "subCount": "47.5",
    "controversyCount": "Multiple"
    },
    {
    "name": "Shakira",
    "genre": "Music",
    "subCount": "47",
    "controversyCount": "Many"
    },
    {
    "name": "Real fools shorts official",
    "genre": "Entertainment",
    "subCount": "46.9",
    "controversyCount": "None"
    },
    {
    "name": "Ishtar Music",
    "genre": "Music",
    "subCount": "46.8",
    "controversyCount": "???"
    }
    ];

const container = document.getElementById('react-data-table');
const root = ReactDOM.createRoot(container);
root.render(<ReactDataTable originalData={youtuberData} />);



}) ();